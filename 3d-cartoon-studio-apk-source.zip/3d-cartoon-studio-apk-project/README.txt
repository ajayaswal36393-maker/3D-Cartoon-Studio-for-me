3D CARTOON STUDIO - ANDROID APK SOURCE PROJECT

STATUS: Android Studio source project; NOT a compiled APK.

This project wraps the included free HTML animation prototype in an Android WebView. On Android, exported WebM videos are saved to Movies/3D Cartoon Studio using Android MediaStore.

BUILD THE APK (requires a Windows/Mac/Linux computer with Android Studio and internet access):
1. Install the latest stable Android Studio.
2. Extract this project ZIP.
3. In Android Studio choose Open and select the extracted 3d-cartoon-studio-apk-project folder.
4. Allow Gradle sync. Install Android SDK Platform 35 if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a notification with a link to the generated APK. It is usually app/build/outputs/apk/debug/app-debug.apk.
7. Transfer app-debug.apk to your Android phone, tap it, and allow installation from that source if Android asks.

APP DETAILS:
- Application name: 3D Cartoon Studio
- Package: com.example.cartoonstudio
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35
- Video export: WebM, saved to Movies/3D Cartoon Studio

LIMITATIONS:
- This is a template-based 3D-style animation maker, not a full AI text-to-video engine.
- The current animation uses stylized graphics and story text; it does not create realistic 3D character animation or automatic Hindi voiceover/music.
- A debug APK is suitable for personal testing. A signed release APK is needed for distribution.

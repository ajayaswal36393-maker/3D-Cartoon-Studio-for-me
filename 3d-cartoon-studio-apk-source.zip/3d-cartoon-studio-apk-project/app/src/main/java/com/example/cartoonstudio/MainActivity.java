package com.example.cartoonstudio;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.net.Uri;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new VideoBridge(), "AndroidStudio");
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class VideoBridge {
        @JavascriptInterface public void saveVideo(String base64Data) {
            runOnUiThread(() -> {
                try {
                    String prefix = "base64,";
                    int comma = base64Data.indexOf(prefix);
                    if (comma >= 0) base64Data = base64Data.substring(comma + prefix.length());
                    byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, "3d-cartoon-short-" + System.currentTimeMillis() + ".webm");
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "video/webm");
                    if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/3D Cartoon Studio");
                    Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Could not create video file");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
                    Toast.makeText(MainActivity.this, "Video saved in Movies / 3D Cartoon Studio", Toast.LENGTH_LONG).show();
                    webView.evaluateJavascript("document.getElementById('status').textContent='Video saved to Movies / 3D Cartoon Studio!';", null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Video save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
